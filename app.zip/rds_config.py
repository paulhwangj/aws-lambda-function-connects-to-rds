#config file containing credentials for RDS MySQL instance
db_username = "paulfortask4"
db_password = "thetaskathand4"
db_name = "ExampleDB" 